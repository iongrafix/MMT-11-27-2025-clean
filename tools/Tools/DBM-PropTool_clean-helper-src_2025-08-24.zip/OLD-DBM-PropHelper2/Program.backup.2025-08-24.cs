using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Runtime.InteropServices;

internal static class Program
{
    static int Fail(string msg, int code = 1) { Console.Error.WriteLine(msg); return code; }

    // ======== COM / Interop ========
    [Flags]
    enum GETPROPERTYSTOREFLAGS : uint
    {
        GPS_DEFAULT    = 0x00000000,
        GPS_READWRITE  = 0x00000002,
    }

    [StructLayout(LayoutKind.Sequential)]
    struct PROPERTYKEY
    {
        public Guid fmtid;
        public uint pid;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct PROPARRAY
    {
        public uint cElems;
        public IntPtr pElems; // pointer to array of IntPtr to LPWSTR
    }

    [StructLayout(LayoutKind.Explicit)]
    struct PROPVARIANT
    {
        [FieldOffset(0)]  public ushort vt;
        [FieldOffset(8)]  public IntPtr ptr;     // LPWSTR or pointer to something
        [FieldOffset(8)]  public int    int32;   // for VT_I4
        [FieldOffset(8)]  public PROPARRAY vector; // for VT_VECTOR of LPWSTR
    }

    const ushort VT_LPWSTR   = 31;
    const ushort VT_I4       = 3;
    const ushort VT_VECTOR   = 0x1000;
    const ushort VT_EMPTY    = 0;

    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPropertyStore
    {
        uint GetCount(out uint cProps);
        uint GetAt(uint iProp, out PROPERTYKEY pkey);
        uint GetValue(ref PROPERTYKEY key, out PROPVARIANT pv);
        uint SetValue(ref PROPERTYKEY key, ref PROPVARIANT pv);
        uint Commit();
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = true)]
    static extern int SHGetPropertyStoreFromParsingName(
        string pszPath,
        IntPtr pbc,
        GETPROPERTYSTOREFLAGS flags,
        ref Guid riid,
        out IPropertyStore ppv);

    [DllImport("propsys.dll", CharSet = CharSet.Unicode, PreserveSig = true)]
    static extern int PSGetPropertyKeyFromName(string pszName, out PROPERTYKEY pkey);

    [DllImport("ole32.dll")]
    static extern int PropVariantClear(ref PROPVARIANT pvar);

    static IntPtr StringToCoTaskMemUni(string s)
    {
        if (s == null) return IntPtr.Zero;
        var bytes = (s.Length + 1) * 2;
        var ptr = Marshal.AllocCoTaskMem(bytes);
        Marshal.Copy(s.ToCharArray(), 0, ptr, s.Length);
        Marshal.WriteInt16(ptr, s.Length * 2, 0);
        return ptr;
    }

    static PROPVARIANT PvFromString(string s)
    {
        return new PROPVARIANT { vt = VT_LPWSTR, ptr = StringToCoTaskMemUni(s ?? "") };
    }

    static PROPVARIANT PvFromInt32(int v)
    {
        return new PROPVARIANT { vt = VT_I4, int32 = v };
    }

    static PROPVARIANT PvFromStringArray(string[] arr)
    {
        // Build array of LPWSTR pointers
        int count = arr?.Length ?? 0;
        if (count <= 0)
            return new PROPVARIANT { vt = (ushort)(VT_VECTOR | VT_LPWSTR), vector = new PROPARRAY { cElems = 0, pElems = IntPtr.Zero } };

        int ptrSize = IntPtr.Size;
        IntPtr block = Marshal.AllocCoTaskMem(ptrSize * count);
        for (int i = 0; i < count; i++)
        {
            var p = StringToCoTaskMemUni(arr[i] ?? "");
            Marshal.WriteIntPtr(block, i * ptrSize, p);
        }
        return new PROPVARIANT {
            vt = (ushort)(VT_VECTOR | VT_LPWSTR),
            vector = new PROPARRAY { cElems = (uint)count, pElems = block }
        };
    }

    static void FreePropVariant(ref PROPVARIANT pv)
    {
        try { PropVariantClear(ref pv); } catch { }
    }

    static int SetString(IPropertyStore ps, string canonicalName, string value)
    {
        int hr = PSGetPropertyKeyFromName(canonicalName, out var key);
        if (hr != 0) return hr;
        var pv = PvFromString(value ?? "");
        try { return (int)ps.SetValue(ref key, ref pv); }
        finally { FreePropVariant(ref pv); }
    }

    static int SetStringArray(IPropertyStore ps, string canonicalName, string[] values)
    {
        int hr = PSGetPropertyKeyFromName(canonicalName, out var key);
        if (hr != 0) return hr;
        var pv = PvFromStringArray(values ?? Array.Empty<string>());
        try { return (int)ps.SetValue(ref key, ref pv); }
        finally { FreePropVariant(ref pv); }
    }

    static int SetInt(IPropertyStore ps, string canonicalName, int v)
    {
        int hr = PSGetPropertyKeyFromName(canonicalName, out var key);
        if (hr != 0) return hr;
        var pv = PvFromInt32(v);
        try { return (int)ps.SetValue(ref key, ref pv); }
        finally { FreePropVariant(ref pv); }
    }

    static string GetString(IPropertyStore ps, string canonicalName)
    {
        int hr = PSGetPropertyKeyFromName(canonicalName, out var key);
        if (hr != 0) return "";
        PROPVARIANT pv = default;
        try
        {
            ps.GetValue(ref key, out pv);
            if (pv.vt == VT_LPWSTR && pv.ptr != IntPtr.Zero)
                return Marshal.PtrToStringUni(pv.ptr) ?? "";
            return "";
        }
        finally { FreePropVariant(ref pv); }
    }

    static int GetInt(IPropertyStore ps, string canonicalName)
    {
        int hr = PSGetPropertyKeyFromName(canonicalName, out var key);
        if (hr != 0) return 0;
        PROPVARIANT pv = default;
        try
        {
            ps.GetValue(ref key, out pv);
            if (pv.vt == VT_I4) return pv.int32;
            return 0;
        }
        finally { FreePropVariant(ref pv); }
    }

    static string[] GetStringArray(IPropertyStore ps, string canonicalName)
    {
        int hr = PSGetPropertyKeyFromName(canonicalName, out var key);
        if (hr != 0) return Array.Empty<string>();
        PROPVARIANT pv = default;
        var list = new string[0];
        try
        {
            ps.GetValue(ref key, out pv);
            if (pv.vt == (VT_VECTOR | VT_LPWSTR) && pv.vector.cElems > 0 && pv.vector.pElems != IntPtr.Zero)
            {
                int n = (int)pv.vector.cElems;
                list = new string[n];
                int ptrSize = IntPtr.Size;
                for (int i = 0; i < n; i++)
                {
                    var pStr = Marshal.ReadIntPtr(pv.vector.pElems, i * ptrSize);
                    list[i] = pStr != IntPtr.Zero ? Marshal.PtrToStringUni(pStr) ?? "" : "";
                }
            }
        }
        finally { FreePropVariant(ref pv); }
        return list;
    }

    [STAThread]
    static int Main(string[] args)
    {
        try
        {
            if (args.Length < 2)
            {
                return Fail("Usage: DBM.PropTool [set|get] --path <file> [--title ... --tags ... --comments ... --rating 0-5]");
            }

            string mode = args[0].ToLowerInvariant();
            string path = "", title = "", tags = "", comments = ""; int ratingStars = 0;

            for (int i = 1; i < args.Length; i++)
            {
                string a = args[i];
                if (a == "--path" && i + 1 < args.Length) path = args[++i];
                else if (a == "--title" && i + 1 < args.Length) title = args[++i];
                else if (a == "--tags" && i + 1 < args.Length) tags = args[++i];
                else if (a == "--comments" && i + 1 < args.Length) comments = args[++i];
                else if (a == "--rating" && i + 1 < args.Length) int.TryParse(args[++i], out ratingStars);
            }
            if (string.IsNullOrWhiteSpace(path)) return Fail("Missing --path");
            path = Path.GetFullPath(path);

            // ensure writable
            try {
                var attrs = File.GetAttributes(path);
                if ((attrs & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                    File.SetAttributes(path, attrs & ~FileAttributes.ReadOnly);
            } catch { }

            // open property store (read/write)
            var iid = typeof(IPropertyStore).GUID;
            int hr = SHGetPropertyStoreFromParsingName(path, IntPtr.Zero, GETPROPERTYSTOREFLAGS.GPS_READWRITE, ref iid, out var store);
            if (hr != 0) return Fail($"SHGetPropertyStoreFromParsingName failed: 0x{hr:X}");

            if (mode == "set")
            {
                // Title, Comment
                hr = SetString(store, "System.Title", title ?? ""); if (hr != 0) return Fail($"Set Title hr=0x{hr:X}");
                hr = SetString(store, "System.Comment", comments ?? ""); if (hr != 0) return Fail($"Set Comment hr=0x{hr:X}");

                // Rating: Explorer uses 0..99. We map 0..5 stars.
                ratingStars = Math.Max(0, Math.Min(5, ratingStars));
                int percent = ratingStars == 0 ? 0 : ratingStars switch { 1 => 1, 2 => 25, 3 => 50, 4 => 75, 5 => 99, _ => 0 };
                // Try SimpleRating first; also set Rating.
                hr = SetInt(store, "System.SimpleRating", percent); if (hr != 0) return Fail($"Set SimpleRating hr=0x{hr:X}");
                hr = SetInt(store, "System.Rating", percent);       if (hr != 0) return Fail($"Set Rating hr=0x{hr:X}");

                // Tags: write vector of strings (split by comma)
                var arr = (tags ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                hr = SetStringArray(store, "System.Keywords", arr);
                if (hr != 0) return Fail($"Set Keywords hr=0x{hr:X}");

                store.Commit();

                Console.WriteLine(JsonSerializer.Serialize(new {
                    ok = true, path,
                    applied = new { title, tags, comments, rating = ratingStars }
                }));
                return 0;
            }
            else if (mode == "get")
            {
                string titleV = GetString(store, "System.Title");
                string commV  = GetString(store, "System.Comment");

                int pct = GetInt(store, "System.SimpleRating");
                if (pct == 0) pct = GetInt(store, "System.Rating");
                int stars = pct <= 0 ? 0 :
                    pct < 13 ? 1 :
                    pct < 38 ? 2 :
                    pct < 63 ? 3 :
                    pct < 88 ? 4 : 5;

                var kw = GetStringArray(store, "System.Keywords");
                string tagsV = string.Join(", ", kw);

                Console.WriteLine(JsonSerializer.Serialize(new {
                    ok = true, path, title = titleV, tags = tagsV, comments = commV, rating = stars
                }));
                return 0;
            }

            return Fail("First arg must be 'set' or 'get'");
        }
        catch (Exception ex)
        {
            return Fail(ex.ToString(), 2);
        }
    }
}
