DBM.PropTool — Clean Helper (patched 2025-08-24)

What changed vs your old helper:
- Tags input now supports both comma and semicolon separators ("," or ";").
- After writing properties we notify Explorer (SHChangeNotify) so Details refresh immediately.

Build (requires .NET 8 SDK on Windows):
1) Open a Developer PowerShell for VS or normal PowerShell
2) cd to this folder
3) dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true

You’ll get the exe at:
  bin\Release\net8.0-windows\win-x64\DBM.PropTool.exe

CLI usage:
  DBM.PropTool.exe set --path "C:\path\file.mp4" --title "Demo" --tags "alpha; beta, gamma" --stars 4 --comments "note"
  DBM.PropTool.exe get --path "C:\path\file.mp4"

Notes:
- Tags are stored in System.Keywords as a string vector (correct type for Explorer).
- Rating is written on Explorer’s 0..99 scale, mapped from stars (1->1, 2->25, 3->50, 4->75, 5->99).
- We also set System.SimpleRating for good measure.
- If the file is read-only, the helper temporarily clears the attribute before writing.
- After writes, Explorer is notified to refresh the item.
